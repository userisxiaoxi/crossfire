var request = Object.create({
    req: function (url, method, data,params, resolve, reject) {
        /*         body: 请求的 body 信息：可能是一个 Blob、BufferSource、FormData、URLSearchParams 或者 USVString 对象。注意 GET 或 HEAD 方法的请求不能包含 body 信息。
                   mode: 请求的模式，如 cors、 no-cors 或者 same-origin,默认为no-cors,该模式允许来自 CDN 的脚本、其他域的图片和其他一些跨域资源，但是首先有个前提条件，就是请求的 method 只能是HEAD、GET 或 POST。此外，如果 ServiceWorkers 拦截了这些请求，它不能随意添加或者修改除这些之外 Header 属性。第三，JS 不能访问 Response 对象中的任何属性，这确保了跨域时 ServiceWorkers 的安全和隐私信息泄漏问题。cors模式允许跨域请求,same-origin模式对于跨域的请求，将返回一个 error，这样确保所有的请求遵守同源策略。
                   credentials: 请求的 credentials，如 omit、same-origin 或者 include。
                   cache:  请求的 cache 模式: default, no-store, reload, no-cache, force-cache, or only-if-cached.*/
        let args = Array.from(arguments).filter(i => i != undefined)
        switch (args.length){
            case 3:
                resolve = data
                data = undefined
                break;
            case 4:
                //无params和reject的情况
                resolve = params
                params = undefined
                break;
            case 5:
                //无params的情况
                if(args.filter(i => (typeof i) == 'function').length == 2){
                    reject = resolve
                    resolve = params
                    params = undefined
                }
                //无reject的情况不处理

                break;
        }
        if(reject == undefined){
            reject = function(error){
                console.error("返回的err是："+error)
            }
        }
        init = {
            method,
            headers: {
                "Content-Type": "application/json",  // 设置请求头参数为json格式
                'token':window.sessionStorage.getItem('token')
            }
        }
        function changeParamsToUrl(pa){
            url += "?"
            for (const key in pa) {
                url += key + "=" + pa[key] + "&"
            }
            url = url.substring(0, url.length - 1);
        }
        switch (method) {
            case "delete":
            case "get":
                if(params == undefined){
                    changeParamsToUrl(data)
                }else{
                    changeParamsToUrl(params)
                    init.body = JSON.stringify(data)
                }
                break;
            case "put":
            case "post":
                if(params != undefined){
                    changeParamsToUrl(params)
                }
                init.body = JSON.stringify(data)
                break;
        }

        fetch(url, init)
            .then(res => {
                if(res.status !== 200){
                    return res.text()
                }
                return res.json()
            })
            .then(resolve)
            .catch(reject)
    }
})
request.post = function(url,data,params,resolve,reject){request.req(url, "post", data,params,resolve,reject)}
request.get = function(url,data,params,resolve,reject){request.req(url, "get", data,params,resolve,reject)}
request.put = function(url,data,params,resolve,reject){request.req(url, "put", data,params,resolve,reject)}
request.delete = function(url,data,params,resolve,reject){request.req(url, "delete", data,params,resolve,reject)}






