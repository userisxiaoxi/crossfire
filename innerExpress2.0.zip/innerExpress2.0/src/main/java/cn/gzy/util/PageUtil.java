package cn.gzy.util;

import lombok.AccessLevel;
import lombok.Data;
import lombok.Setter;

import java.util.List;
@Data
public class PageUtil<T> {
    private Integer current;
    private Integer size;
    @Setter(AccessLevel.NONE)  //不允许手动设置最大页码
    private Integer totalSize;
    private Integer totalNumber;
    private List<T> list;

    public PageUtil(Integer current,Integer size,Integer totalNumber){
        setSize(size);
        setTotalNumber(totalNumber);
        setCurrent(current);
    }

    public void setTotalNumber(Integer totalNumber){
        this.totalNumber = totalNumber;
        if(totalNumber < this.size){
            this.totalSize = 1;
        }else{
            this.totalSize = this.totalNumber % this.size == 0 ?
                    this.totalNumber / this.size : this.totalNumber / this.size + 1;
        }

    }

    public void setSize(Integer size){
        if(size < 1){
            this.size = 1;
        }else if(size > 100){
            this.size = 100;  // 每页最多100条
        }else{
            this.size = size;
        }
    }

    public void setCurrent(Integer current){
        if(current > this.totalSize){
            this.current = this.totalSize;
        }else if (current < 1){
            this.current = 1;
        }else{
            this.current = current;
        }
    }
}
