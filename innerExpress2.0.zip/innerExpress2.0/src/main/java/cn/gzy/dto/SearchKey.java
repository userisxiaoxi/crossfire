package cn.gzy.dto;

import lombok.Data;

@Data
public class SearchKey {
    private String key;
}
