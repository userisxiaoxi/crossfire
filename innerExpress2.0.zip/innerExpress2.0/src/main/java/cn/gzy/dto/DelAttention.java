package cn.gzy.dto;

import lombok.Data;

@Data
public class DelAttention {
    private Integer type;
    private Integer id;
}
