package cn.gzy.dto;

import lombok.Data;

@Data
public class PageBo {
    private Integer current;
    private Integer size;
}
